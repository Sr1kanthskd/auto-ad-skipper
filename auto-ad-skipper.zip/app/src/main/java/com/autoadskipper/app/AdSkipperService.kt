package com.autoadskipper.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log
import android.content.Context

class AdSkipperService : AccessibilityService() {
    
    private val TAG = "AdSkipperService"

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        
        val sharedPrefs = getSharedPreferences("AdSkipperPrefs", Context.MODE_PRIVATE)
        if (!sharedPrefs.getBoolean("is_skipping_enabled", true)) return

        val rootNode = rootInActiveWindow ?: return
        if (rootNode.packageName?.toString() != "com.google.android.youtube") return
        
        if (clickNodeByText(rootNode, "Skip ad")) return
        if (clickNodeByText(rootNode, "Skip ads")) return
        if (clickNodeByText(rootNode, "Skip")) return
    }
    
    private fun clickNodeByText(node: AccessibilityNodeInfo, searchText: String): Boolean {
        val foundNodes = node.findAccessibilityNodeInfosByText(searchText)
        for (foundNode in foundNodes) {
            val nodeText = foundNode.text?.toString()?.lowercase() 
                           ?: foundNode.contentDescription?.toString()?.lowercase() 
                           ?: ""
            
            // Allow if it matches "skip ad", "skip ads", or exactly "skip"
            if (nodeText.contains("skip ad") || nodeText.contains("skip ads") || nodeText == "skip") {
                if (foundNode.isClickable) {
                    foundNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Clicked skip button.")
                    return true
                } else {
                    var parent = foundNode.parent
                    while (parent != null) {
                        if (parent.isClickable) {
                            parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            Log.d(TAG, "Clicked skip button parent.")
                            return true
                        }
                        parent = parent.parent
                    }
                }
            }
        }
        return false
    }

    override fun onInterrupt() {
        // Nothing to do
    }
}
