package com.autoadskipper.app

object AdConstants {
    const val BANNER_AD_UNIT_ID = "ca-app-pub-1932081965171538/8488598754"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-1932081965171538/5670863723"
}
