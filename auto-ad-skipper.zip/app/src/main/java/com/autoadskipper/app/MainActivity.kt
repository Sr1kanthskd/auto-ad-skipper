package com.autoadskipper.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.autoadskipper.app.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AutoAdSkipperScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoAdSkipperScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var isServiceEnabled by remember { mutableStateOf(false) }
    var showHowItWorks by remember { mutableStateOf(false) }

    val sharedPrefs = context.getSharedPreferences("AdSkipperPrefs", Context.MODE_PRIVATE)
    var isAppEnabled by remember { mutableStateOf(sharedPrefs.getBoolean("is_skipping_enabled", true)) }

    // Update service status when returning to the app
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isServiceEnabled = isAccessibilityServiceEnabled(context, AdSkipperService::class.java)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val isActive = isServiceEnabled && isAppEnabled

    LaunchedEffect(Unit) {
        InterstitialAdManager.loadAd(context)
    }

    Scaffold(
        containerColor = Color(0xFF050510), // Dark background
        bottomBar = {
            BannerAd()
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(
                    colors = listOf(Color(0xFF13082A), Color(0xFF050510))
                ))
                .padding(paddingValues)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(48.dp))
            
            AppLogo()
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Auto Ad Skipper",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Automatically skips ads so you\ncan enjoy uninterrupted videos.",
                textAlign = TextAlign.Center,
                color = Color(0xFFB0B0C4),
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Status Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0F1F)),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, if (isActive) Color(0xFF00FF7F) else Color(0xFF33334D)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(
                                color = if (isActive) Color(0xFF00FF7F).copy(alpha = 0.15f) else Color.DarkGray.copy(alpha = 0.3f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isActive) Icons.Default.Security else Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = if (isActive) Color(0xFF00FF7F) else Color.Gray,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "Service Status",
                        color = if (isActive) Color(0xFF00FF7F) else Color.Gray,
                        fontWeight = FontWeight.Medium,
                        fontSize = 15.sp
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = if (isActive) "ON" else "OFF",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) Color(0xFF00FF7F) else Color.White
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = if (isActive) "Auto Ad Skipper is active and running." else "Auto Ad Skipper is currently disabled.",
                        color = Color(0xFFB0B0C4),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Main Button
            Button(
                onClick = {
                    val performAction = {
                        if (!isServiceEnabled) {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        } else {
                            isAppEnabled = !isAppEnabled
                            sharedPrefs.edit().putBoolean("is_skipping_enabled", isAppEnabled).apply()
                        }
                    }
                    val activity = context as? android.app.Activity
                    if (activity != null) {
                        InterstitialAdManager.showAd(activity) {
                            performAction()
                        }
                    } else {
                        performAction()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                ),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFFFF9A44),
                                    Color(0xFFFC6076),
                                    Color(0xFFFF00FF)
                                )
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isActive) "Turn Off Auto Ad Skipper" else "Turn On Auto Ad Skipper",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // How it works Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141124)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showHowItWorks = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFF6B21A8), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("i", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = "How It Works", fontWeight = FontWeight.SemiBold, color = Color.White, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFFB0B0C4))
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Info Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141124)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF3B2A82), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFA78BFA), modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "We only use Accessibility permission\nto detect and click the Skip button.",
                            color = Color(0xFFB0B0C4),
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "We do not collect any data.",
                            color = Color(0xFFA78BFA),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    if (showHowItWorks) {
        AlertDialog(
            onDismissRequest = { showHowItWorks = false },
            containerColor = Color(0xFF141124),
            titleContentColor = Color.White,
            textContentColor = Color(0xFFB0B0C4),
            title = { Text("How it Works") },
            text = {
                Column {
                    Text("• The app only works after Accessibility permission is enabled.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• The app does not modify YouTube.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• The app simply automates pressing the Skip button when it becomes available.")
                }
            },
            confirmButton = {
                TextButton(onClick = { showHowItWorks = false }) {
                    Text("Got it", color = Color(0xFFA78BFA))
                }
            }
        )
    }
}

@Composable
fun AppLogo() {
    Image(
        painter = painterResource(id = R.drawable.app_logo),
        contentDescription = "App Logo",
        modifier = Modifier
            .size(100.dp)
            .clip(RoundedCornerShape(24.dp)),
        contentScale = ContentScale.Fit
    )
}

fun isAccessibilityServiceEnabled(context: Context, accessibilityService: Class<*>): Boolean {
    val expectedComponentName = ComponentName(context, accessibilityService)
    val enabledServicesSetting = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false

    val colonSplitter = TextUtils.SimpleStringSplitter(':')
    colonSplitter.setString(enabledServicesSetting)
    while (colonSplitter.hasNext()) {
        val componentNameString = colonSplitter.next()
        val enabledService = ComponentName.unflattenFromString(componentNameString)
        if (enabledService != null && enabledService == expectedComponentName) {
            return true
        }
    }
    return false
}
